import java.io.IOException;


public class main {
    static dataManager dm; //get a instance of our datamanager (opens our FSDirectory or creates it if it doesnt exist)


    public static void main(String[] args) throws IOException, InterruptedException {
        new gui();
    }
}
